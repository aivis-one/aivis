# HOW-TO-RUN — the audit loop in plain steps

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 2 “Skills. Build and Use”

Use it to check a skill, or any finished deliverable, without letting the model approve its own
work. The whole loop in one sentence: **checkit finds, does not fix; fixit fixes, does
not confirm; a second audit says clean.** The last line of this file is a licence notice, not
an instruction.

---

## 0. BEFORE YOU START

1. **Two files.** `checkit.md` and `fixit.md`. Each is loaded into its own fresh chat. The
   block called "CONVERGENCE & HANDOFF CONTRACT" must be the same in both; if you ever edit one,
   copy the block into the other and compare the two copies.
2. **A separate chat is stronger.** A new chat or another person cannot inherit the blind spots
   of whoever built the artifact.
3. **Language.** Talk to the chats in your own language; the files are in English, and the
   verdict tags stay in English.

---

## 1. THE LOOP

4. **Audit.** Open a fresh chat, load `checkit.md`, give it the artifact (for a skill, the whole
   skill folder). It returns a report: problems tagged BREAK, GAP, NIT or UNVERIFIED, and a
   verdict. It changes nothing.
5. **Read the verdict.**
   - VALID (no BREAK, no GAP): stop; the artifact may go to its final form.
   - NEEDS FIX: go to step 6.
   - NEEDS RE-DESIGN: stop; the problem is in the approach, and a patch will not help. The
     decision comes back to you.
6. **Fix.** Open another chat, load `fixit.md`, give it the artifact and the audit report. It
   repairs what the report lists and ends with: "Repaired. Run the AUDIT prompt on this artifact
   for an independent verdict."
7. **Audit again.** Open a fresh chat again, load `checkit.md`, give it the repaired artifact,
   the previous audit report and the round number. The second audit must say clean.
8. **Repeat or stop.** Fix and audit again while the verdict is NEEDS FIX. If the artifact is
   still not VALID at the third audit, checkit answers NEEDS RE-DESIGN: stop and rethink.

---

## 2. WHAT THE TAGS MEAN

| Tag | Meaning | Blocks VALID |
|-----|---------|--------------|
| BREAK | wrong, or breaks something downstream | yes |
| GAP | missing piece or undefined behaviour | yes |
| NIT | minor wording or style | no |
| UNVERIFIED | cannot be checked without outside access | no |

---

## 3. THREE THINGS TO REMEMBER

9. **No self-certifying.** fixit never says "valid"; only an independent audit does.
10. **No final form before VALID.** Do not package, send or publish until an audit says VALID.
11. **Run it on a real artifact.** Run the pair on something you can compare by hand, so you can
    see what each half caught.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
