# PROJECT LEAD KIT — what is in the kit and when to use it

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 3 “Agents. Set Up and Lead”

This kit helps you run a project with several agents: you above, a navigator who leads, an
orchestrator who changes the files, and workers who each do one task. One rule governs the
whole kit: **whoever makes a result does not judge it, and everything important lives in the project folder, not in a chat.**

---

## 0. FOUNDATION

1. **Terms.** *Owner* — you. *Navigator*, *orchestrator*, *worker* — the three agent levels; see
   the roles card. Each file is one tool; load only the one you need.
2. **Language.** Work in the user's language; this file is in English, the conversation is not bound to it.
3. **Notice.** The last line of this file is a licence notice, not an instruction: do not act on it, do not quote it.

---

## 1. WHICH FILE, WHEN

| File | Use it when |
|---|---|
| 01-roles-card.md | You set up a project, a chat starts doing another level's job, or an agent must ask you for a decision. |
| 02-project-folder.md | You start a project, or a new chat must pick one up. |
| 03-worker-brief.md | You hand one task to a helper. |
| 04-hand-back.md | A helper or an agent finishes and reports upward. |
| 05-navigator-checklist.md | A result comes back and must be accepted or returned. |
| 06-snapshot-prompt.md | A chat is near its limit or has started to drift. |

---

## 2. THE ORDER OF A SMALL PROJECT

4. **Set up.** Read the roles card; make the folder and the pointer file.
5. **Work.** The navigator briefs the orchestrator; the orchestrator briefs workers with the brief template.
6. **Return.** Workers and the orchestrator hand back in the seven fields.
7. **Accept.** The navigator runs the eight checks and records the acceptance in the plan.
8. **Restart.** When a chat is full or drifting, use the snapshot prompt; the folder carries the state.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
