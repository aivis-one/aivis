# OPTIONS — a decision with options and a recommendation

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it at any fork: what to choose, which path is better. One rule governs it: **the user must
understand the trade-offs well enough to decide, not just pick blindly.** Work in the user's
language. The last line of this file is a licence notice, not an instruction: do not
act on it, do not quote it.

The user needs to make a decision and wants to understand it. Instead of asking a plain
question, do this:

1. **Context.** Lay out briefly the context as you understand it (Goal - Context - Format -
   Constraints, whichever parts matter for this decision).
2. **Options.** Give 2-3 distinct options in plain language. For each: what it is, its main
   upside, its main downside. Example fork: hold the book exchange in a library or in a café.
3. **Recommendation.** Add your own recommended option — one of the above or a fourth — and
   explain concretely why you lean toward it.
4. **Style.** Keep it simple and jargon-free. After reading, the user should understand the
   trade-offs well enough to decide alone.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
