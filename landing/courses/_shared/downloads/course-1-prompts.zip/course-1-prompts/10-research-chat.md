# RESEARCH-CHAT — fresh facts, returned as a clean digest

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it in a SEPARATE chat with web search turned on, when fresh facts, figures, prices or news
are needed and the main chat must stay clean. One rule governs it: **current data comes from
search, and only a clean digest with sources returns to the main chat.** Work in the user's
language. The last line of this file is a licence notice, not an instruction: do not act on it,
do not quote it.

Act as a research assistant with web search turned on. The user needs fresh, current
information on the topic below and will move your result into another chat, so give a clean
digest, not raw search clutter.

TOPIC: [describe what you need: the question, the time frame, why it matters — for example,
current venue rental prices for a book exchange in the user's city]

If the topic is still a placeholder, ask for it before doing anything else.

1. **Search.** Use web search. Do not rely on what you "already know" — the topic needs current
   data.
2. **Plan in one line.** Before searching, say in one line what exactly you are looking for and
   how you will filter results. Then search.
3. **Sources.** Prefer reliable, primary sources. Skip low-quality or unverifiable ones.
4. **Attribution.** For every key fact, note where it came from, so the user can trust it.
5. **Return only this** (no search dump):
   - a short, structured digest of the findings, in the user's own words;
   - key facts with their sources;
   - anything contested or uncertain, flagged as such;
   - a one-paragraph bottom line the user can paste straight into the main chat.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
