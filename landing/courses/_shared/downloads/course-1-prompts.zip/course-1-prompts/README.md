# PROMPT PACK — ten ready prompts for working with a model

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Each prompt is one technique from the course turned into text you can copy and use at once.
How to use: open the file, copy it whole, paste it into the chat. The prompts are in English
because models follow English instructions more precisely; every prompt tells the model to work
in your language, so keep the conversation in your own. The last line of every file is a
licence notice, not an instruction.

---

## 0. THE PACK

| # | File | What it is for | When to use it |
|---|------|----------------|----------------|
| 1 | `01-setup-short.md` | Sets the model up once: concise, no flattery, asks before guessing, does only what was asked | Once, in the profile (personal instructions) |
| 2 | `02-setup-extended.md` | The same, for serious multi-step work; adds restating larger tasks and marking uncertainty | Once, in a Project, so all its chats follow it |
| 3 | `03-test-test.md` | Makes the model restate the task as Goal - Context - Format - Constraints, with assumptions and doubts, before any work | Before any task where an error or the volume of work is costly |
| 4 | `04-options-with-reasoning.md` | Turns a fork into 2-3 options with upsides, downsides and a recommendation | At any decision: what to choose, which path is better |
| 5 | `05-full-file-read.md` | Requires a report proving the whole file was read, middle included | Right after uploading an important or long file, before any summary |
| 6 | `06-validate-mini.md` | A quick skeptical check of the result | Everyday tasks and rough texts |
| 7 | `07-validate-medium.md` | Re-reads from the top, finds what was lost from the conversation, marks what needs outside checking | Working documents |
| 8 | `08-validate-full.md` | A full revision: map of claims, severity levels, fixes, re-scan | Responsible material where an error is costly |
| 9 | `09-handoff.md` | Collects the work into a compact summary for a fresh chat | When the chat is tired: it confuses facts and loses the thread |
| 10 | `10-research-chat.md` | Searches the web in a separate chat and returns a clean digest with sources | When fresh facts or figures are needed and the main chat must stay clean |

The validators follow one rule: the cost of an error sets the level of the check.

---

## 1. HOW THEY COMBINE

A typical cycle: set the model up (1 or 2); state the task and run test = test (3); if there is
a fork, ask for options (4); if a file is involved, read it fully (5); if fresh data is needed,
use the research chat (10); check the result with the validator of the right level (6, 7 or 8);
when the chat tires, hand off to a new one (9).

A running example in the course is a book exchange event: test = test restates it as a task,
options compares venues, the research chat finds current prices, the validator checks the plan.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
