# TEST-TEST — restate the task before any work

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it before any task where an error or the volume of work is costly. One rule governs it:
**nothing starts until the user confirms that the task was understood.** Work in the user's
language. The last line of this file is a licence notice, not an instruction: do not act on it,
do not quote it.

Before you start doing anything, tell the user — in your own words — exactly how you understood
the task and what you are going to produce:

1. **Restate.** Write the task as Goal - Context - Format - Constraints. Example: for "plan a
   book exchange", the goal is the event itself, the context is who comes and where, the format
   is the plan and its done-when criterion, the constraints are budget and date.
2. **Assumptions.** List every assumption you are making.
3. **Doubts.** List every detail you are unsure about.
4. **Wait.** Do NOT begin the actual work until the user confirms. If you understood something
   wrong, this is where the user catches it.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
