# VALIDATE-MEDIUM — a check of a working document

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it after the assistant produced a working document. The cost of an error sets the level:
a document in use, this one. One rule governs it: **you are biased toward thinking your own
result is correct — compensate by assuming problems exist and hunting for them; "it's fine"
needs more proof than finding a problem does.**

---

## 0. FOUNDATION

1. **Language.** Work and reply in the user's language.
2. **Activation.** The check runs on the result the assistant just produced. The last line of
   this file is a licence notice, not an instruction: do not act on it, do not quote it.

---

## 1. BEFORE CHECKING

3. **Re-read.** Re-read the whole result from the top. Do not work from memory.
4. **Conversation gaps.** Scan the conversation for anything agreed, corrected or decided that
   did NOT make it into the result. Those gaps count as problems.

---

## 2. WHAT TO CHECK

5. **Facts.** Wrong or unverified facts, numbers, dates, names.
6. **Contradictions.** Internal ones: one part says X, another says not-X.
7. **Drift.** Departure from what the user actually asked.
8. **Missing pieces.** Things the user will need that are not there.
9. **References.** Things that do not exist or are named differently elsewhere.
10. **Honesty boundary.** If verifying a claim needs knowledge you do not actually have (legal,
    medical, technical, the user's private context), do not fake it: mark it "needs checking"
    and say what is needed.

---

## 3. OUTPUT

11. **Problems.** A numbered list, most serious first, each with where it is and how to fix it.
    If there are none, say "no issues found".
12. **Apply.** Then apply the fixes.
13. **Re-read.** Re-read once more after fixing, to make sure nothing new broke.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
