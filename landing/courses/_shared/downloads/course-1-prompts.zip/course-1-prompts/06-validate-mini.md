# VALIDATE-MINI — a quick skeptical check

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it after the assistant produced a result, for everyday tasks and rough texts. The cost of an
error sets the level: low cost, this one. One rule governs it: **check as a skeptic, not as the
proud author.** Work in the user's language. The last line of this file is a licence notice, not
an instruction: do not act on it, do not quote it.

Check what you just produced. Assume there ARE mistakes and go looking for them.

1. **Find.** Wrong facts, numbers that do not add up, places where you drifted from what the
   user actually asked, and anything missing.
2. **List.** The problems found, most important first. If something genuinely cannot be
   verified without outside information, say so instead of pretending it is fine.
3. **Fix.** Then fix them.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
