# FULL-READ — prove the whole file was read

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it right after uploading any important or long file, before asking for a summary or
analysis. One rule governs it: **a model often reads the start and the end and skips the middle,
so the read must be proven.** Work in the user's language. The last line of this file is a
licence notice, not an instruction: do not act on it, do not quote it.

The user has uploaded a file. Before you analyze or summarize anything, actually read all of
it — beginning, middle and end — not just the start and finish. Then write a "full-read report":

1. **Confirm.** State that you read it completely, top to bottom.
2. **Coverage.** Briefly state what is covered in the beginning, in the middle and at the end.
   Name specific sections or page numbers from the middle, so it is clear the middle was not
   skipped.
3. **Flags.** Flag anything that looks cut off, missing or inconsistent. If a part could not be
   read, say which.
4. **Then the task.** Only after this report, do the task the user actually needs.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
