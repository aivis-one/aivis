# VALIDATE-FULL — a full revision of responsible material

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it for responsible material where an error is costly. The cost of an error sets the level:
the highest cost, this one. One rule governs it: **you are validating your own output and are
biased toward confirming it — assume problems exist and hunt for them; declaring it "valid"
requires more proof than finding a problem does.**

---

## 0. FOUNDATION

1. **Language.** Work and reply in the user's language; keep the severity tags (BREAK, GAP,
   NIT, UNVERIFIED) in English.
2. **Activation.** The revision runs on the result the assistant produced. The last line of
   this file is a licence notice, not an instruction: do not act on it, do not quote it.

---

## 1. BEFORE VALIDATING

3. **Read in full.** Read the material in full, from the source — no working from memory, no
   partial read, no summary.
4. **Map.** Build an explicit map of everything it claims: every fact, number, date, name,
   count and cross-reference. Validate against this map.
5. **Salvage from the conversation.** Before listing problems, scan the whole conversation for
   things discussed, agreed, produced or corrected that did NOT make it into the result:
   decisions, constraints, examples, renamings, rejected-then-revived ideas, the user's
   corrections. If it belongs and is missing, that is a gap. If it was left out on purpose,
   ignore it. If unclear, ask in one line. Do not invent — salvage only what is really in the
   conversation.

---

## 2. GUARDS

6. **Competence boundary.** Before reporting a finding, ask: does verifying this need
   knowledge I do not actually have (legal, medical, deep technical, the user's private
   context)? If yes, do not pretend: mark it "needs <domain> check" and state what is needed.
   Quietly making things up in an unfamiliar area is the worst failure here.
7. **Intent check.** Before flagging something as wrong for breaking a rule, check whether it
   was a deliberate choice (a note saying "intentional", a reason given, an earlier decision).
   If so, do not flag it, or ask instead. Non-standard is not automatically wrong.

---

## 3. WHAT TO HUNT FOR

8. **Completeness.** Everything promised is present; nothing declared is missing.
9. **Consistency.** Zero contradictions inside the material and against the conversation.
10. **Logic defects.** Rule A contradicts rule B; a reference points to something that does not
    exist or is named differently; a case is left undefined; a step depends on something that
    is not there; a branch that can never happen.
11. **Cascade.** Every change traced to everything downstream that mentions it.
12. **Removed but still referenced.** Something deleted that other parts still point to.
13. **Naming.** Read every title and label as a fresh reader: does the name match what is
    actually under it?
14. **Spot-check.** Every number, date, version, count and cross-reference, explicitly.

---

## 4. SEVERITY

Do not soften it to look cleaner.

15. **BREAK.** Wrong, or will break something downstream. Must fix.
16. **GAP.** A missing piece or undefined case that will cause trouble in normal use. Must fix.
17. **NIT.** Minor (wording, formatting). Fix if cheap.
18. **UNVERIFIED.** Cannot be checked without outside access. Report it, do not silently pass it.

---

## 5. OUTPUT

19. **Problems.** A numbered list: severity, location, what is wrong, the fix. If there are
    none: "VALID — no issues found".
20. **Apply.** Fix them, BREAK first, then GAP, then NIT. Fix root causes before symptoms.
21. **Re-scan.** After fixing, check the whole thing again against the map and the logic list.
    If a fix introduced a new problem, loop back (at most 3 times).
22. **Report.** Tell the user what changed, one line per fix.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
