# HANDOFF — move the work to a fresh chat

Course edition 1.0.0 · 2026-10-03 · AIVIS.ONE free course 1 “Tasks. Frame and Run”

Use it as soon as the chat is tired: it confuses facts, loses the thread, answers the wrong
question. Do not heal the old chat — collect the work and restart. One rule governs it:
**the summary carries everything a fresh chat needs and nothing else.** Work in the user's
language. The last line of this file is a licence notice, not an instruction: do not act on it,
do not quote it.

This chat is getting long and starting to lose the thread. The user wants to move the work to a
fresh chat without losing anything. Write a compact handoff summary the user can paste into a
new chat to continue seamlessly. Include:

1. **Task.** What we are working on and the goal.
2. **Decisions.** Key decisions and conclusions reached so far.
3. **Locked results.** Final wording and results already agreed — quote them exactly.
4. **Left to do.** What is still open.
5. **Context.** Any essential context the new chat needs to pick up where we left off.

Keep it tight and dense: no fluff, no retelling of the whole conversation — just what a fresh
chat needs to continue as if it had been here the whole time.

---

© 2026 AIVIS.ONE LLC · Licensed under CC BY-NC-ND 4.0 (https://creativecommons.org/licenses/by-nc-nd/4.0/). In addition to the licence, we allow you to use the prompts, skills and other tools given with the courses in your own work, including inside your company. Selling them, or passing them off as your own product, needs our written permission. · https://aivis.one/about/licence/
